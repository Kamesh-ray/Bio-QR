const Footer = () => {
  return (
    <footer style={{ textAlign: "center", marginTop: "50px" }}>
      <p>© 2025 Bio QR App. Created by <strong>Kamesh</strong></p>
    </footer>
  );
};

export default Footer;
